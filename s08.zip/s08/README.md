# S08 – Bike Parking

## Project files

- `mini-capstone.blend` – Blender project model.
- `bike-parking-sketch.pdf` – reference sketch.
- `images/` – screenshots of the model from multiple viewpoints.

## Screenshots

1. Top view
2. Front view
3. Rear view
4. Side view 1
5. Side view 2

## Software

- Blender 4.5.14 LTS
- Bonsai BIM 0.8.5

## Notes

The screenshots document the model's visible geometry and viewpoints.
An IFC export was not included in the supplied files.
